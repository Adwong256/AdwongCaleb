classdef IntergrationProblem < NumericalSolver
    % Inherits from NumericalSolver and implements ODE integration methods.

    properties (Access = private)
        % Encapsulation: ODE-specific parameters (from the prompt).
        r = 0.1;   % growth rate
        k = 1000;  % carrying capacity
        tspan = [0, 50]; 
        num_steps = 500; 
        time_points;
        solution_y;
        method_used = 'None';
    end

    methods
        function obj = IntergrationProblem(~, initial_pop)
            % Constructor: Pass a dummy func, use initial_pop as initial_data.
            % The actual ODE (dP/dt) is defined within the solver methods.
            obj = obj@NumericalSolver(@(t, y) 0, initial_pop); 
            obj.time_points = linspace(obj.tspan(1), obj.tspan(2), obj.num_steps);
        end
        
        function solve(obj, method)
            % Polymorphism: Implements the abstract 'solve' method.
            obj.method_used = lower(method);
            
            % The core ODE function for the Logistic model
            f_ode = @(P) obj.r * P * (1 - P / obj.k);

            switch obj.method_used
                case 'euler'
                    [obj.time_points, obj.solution_y] = obj.eulerMethod(f_ode);
                case 'rungekutta'
                    [obj.time_points, obj.solution_y] = obj.rungeKutta4(f_ode);
                otherwise
                    error('Unsupported ODE solver method: %s.', method);
            end
        end

        function displayResults(obj)
            % Polymorphism: Implements the abstract 'displayResults'.
            fprintf('\n Intergral Solver (%s) Results:\n', upper(obj.method_used));
            fprintf('  Initial Population (P0): %g\n', obj.initial_data);
            fprintf('  Parameters: r=%.1f, K=%g, Timespan=[%g, %g]\n', obj.r, obj.k, obj.tspan(1), obj.tspan(2));
            
            if ~isempty(obj.solution_y)
                idx_mid = ceil(length(obj.solution_y) / 2);
                fprintf('  Population (t=0): %.2f\n', obj.solution_y(1));
                fprintf('  Population (t=%.2f): %.2f\n', obj.time_points(idx_mid), obj.solution_y(idx_mid));
                fprintf('  Population (t=%.2f): **%.2f** (Final)\n', obj.time_points(end), obj.solution_y(end));
            else
                fprintf('  Failure: Solver was not executed.\n');
            end
            fprintf('--------------------------------------------------\n');
        end
    end

    methods (Access = private)
        % Encapsulated methods for the algorithms
        
        function [t, y] = eulerMethod(obj, f_ode)
            t = obj.time_points;
            h = t(2) - t(1); 
            y = zeros(size(t));
            y(1) = obj.initial_data; 

            for i = 1:length(t)-1
                y(i+1) = y(i) + h * f_ode(y(i));
            end
        end

        function [t, y] = rungeKutta4(obj, f_ode)
            t = obj.time_points;
            h = t(2) - t(1);
            y = zeros(size(t));
            y(1) = obj.initial_data;

            for i = 1:length(t)-1
                y_i = y(i);
                
                % RungeKutta4 steps
                k1 = f_ode(y_i);
                k2 = f_ode(y_i + h/2 * k1);
                k3 = f_ode(y_i + h/2 * k2);
                k4 = f_ode(y_i + h * k3);
                
                y(i+1) = y_i + (h/6) * (k1 + 2*k2 + 2*k3 + k4);
            end
        end
    end
end