% A. Root-Finding Problem (NRM & Secant)
% Function: 10000000 * (1 + r).^12 - 15000000 = 0
RootFunction = @(r) 10000000 * (1 + r).^12 - 15000000;

% 1. NRM Test: Needs one initial guess
nrm_solver = DifferentialProblem(RootFunction, 0.03); 
nrm_solver.solve('NRM');
nrm_solver.displayResults(); 
% Expected Root (r): ~0.034366 (or 3.4366% interest rate)

% 2. Secant Test: Needs two initial guesses
secant_solver = DifferentialProblem(RootFunction, [0.03, 0.04]);
secant_solver.solve('Secant');
secant_solver.displayResults();


% B. Integral Problem (Euler & Runge-Kutta 4)
% The problem function is implicitly the Logistic Model: dP/dt = r*P*(1 - P/K)
% Initial Population P0 = 100

% 3. Euler Method Test
% Initial data is P0=100. (The first argument @(t,y)0 is a dummy function.)
euler_solver = IntergrationProblem(@(t,y)0, 100); 
euler_solver.solve('Euler');
euler_solver.displayResults();


% 4. Runge-Kutta 4 Test
rk4_solver = IntergrationProblem(@(t,y)0, 100);
rk4_solver.solve('RungeKutta');
rk4_solver.displayResults(); 
% Final Population (t=50) should be very close to the carrying capacity K=1000.